﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Linq;

namespace Raktarprogram
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class BelepesWindow : Window
    {
        public BelepesWindow()
        {
            InitializeComponent();
        }

        private void Bejelentkezes_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (User.users.Exists(elem=>elem.nev == felhasznalonevTextBox.Text && elem.kod == jelszoTextBox.Password))
                {
                    User.felhasznalonev = felhasznalonevTextBox.Text;
                    User.jelszo = jelszoTextBox.Password;
                    MainWindow mainWindow = new MainWindow();
                    mainWindow.Show();
                    mainWindow.termekekGomb.IsEnabled = true;
                    mainWindow.statisztikaGomb.IsEnabled = true;
                    mainWindow.eladasGomb.IsEnabled = true;
                    mainWindow.belepesGomb.IsEnabled = false;
                    this.Close();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}