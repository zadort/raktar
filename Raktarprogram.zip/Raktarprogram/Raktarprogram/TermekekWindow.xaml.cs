﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Raktarprogram
{
    /// <summary>
    /// Interaction logic for TermekekWindow.xaml
    /// </summary>
    public partial class TermekekWindow : Window
    {
        public TermekekWindow()
        {
            InitializeComponent();
            lista.ItemsSource = Termek.termeklista;
        }

        private void felvitel_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ProductNameTextBox.Text != "" && ItemCodeTextBoxInFelvitel.Text != "")
                {
                    Termek.termeklista.Add(new Termek(int.Parse(ItemCodeTextBoxInFelvitel.Text),ProductNameTextBox.Text));
                    lista.Items.Refresh();
                    Termek.Save();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void torol_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ItemCodeTextBoxInTorles.Text != "")
                {
                    Termek.termeklista.Remove(Termek.termeklista.Where(k=>k.id==int.Parse(ItemCodeTextBoxInTorles.Text)).First());
                    lista.Items.Refresh();
                    Termek.Save();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
