﻿using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Xps.Packaging;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Linq;

namespace Raktarprogram
{
    /// <summary>
    /// Interaction logic for StatisztikaWindow.xaml
    /// </summary>
    public partial class StatisztikaWindow : Window
    {
        private static Dictionary<string, int> sales = new Dictionary<string, int>();
        public StatisztikaWindow()
        {
            InitializeComponent();

            for (int i = 0; i < mentes.eladasok.Count; i++)
            {
                sales[mentes.eladasok[i].nev] += mentes.eladasok[i].mennyiseg;
            }
            lista.ItemsSource = sales;
        }
        private void nyomtatas_Click(object sender, RoutedEventArgs e)
        {
            StreamWriter streamWriter = new StreamWriter("nyomtatas.txt");
            foreach (var item in sales)
            {
                Console.WriteLine($"{item.Key};{item.Value}");
            }
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            mainWindow.termekekGomb.IsEnabled = true;
            mainWindow.statisztikaGomb.IsEnabled = true;
            mainWindow.eladasGomb.IsEnabled = true;
            mainWindow.belepesGomb.IsEnabled = false;
            this.Close();
        
        }
    }
}
