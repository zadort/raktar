﻿using System.Configuration;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Raktarprogram
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            StreamReader sr = new StreamReader("User.txt");
            while (!sr.EndOfStream)
            {
                User.users.Add(new User(sr.ReadLine()));
            }
            sr.Close();

            StreamReader sr2 = new StreamReader("termekek.txt");
            while (!sr2.EndOfStream)
            {
                Termek.termeklista.Add(new Termek(sr2.ReadLine()));
            }
            sr2.Close();
            if (File.Exists("eladasok.txt"))
            {
                StreamReader sr3 = new StreamReader("eladasok.txt");
                while (!sr3.EndOfStream)
                {
                    mentes.eladasok.Add(new mentes(sr3.ReadLine()));
                }
                sr3.Close();
            }
            else
            {
                StreamWriter sw = new StreamWriter("eladasok.txt");
                sw.Close();
            }
        }

        private void BelepesMenu_Click(object sender,RoutedEventArgs e)
        {
            BelepesWindow belepes = new BelepesWindow();
            belepes.Show();
            this.Close();
        }

        private void termekek_Click(object sender, RoutedEventArgs e)
        {
            TermekekWindow termekekWindow = new TermekekWindow();
            termekekWindow.Show();
            this.Close();
        }

        private void eladas_Click(object sender, RoutedEventArgs e)
        {
            EladasWindow eladasWindow = new EladasWindow();
            eladasWindow.Show();
            this.Close();
        }

        private void statisztika_Click(object sender, RoutedEventArgs e)
        {
            StatisztikaWindow statisztikaWindow = new StatisztikaWindow();
            statisztikaWindow.Show();
            this.Close();
        }

        private void kilepes_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }
    }
    class User
    {
        public static string felhasznalonev;
        public static string jelszo;

        public static List<User> users = new List<User>();

        public string nev;
        public string kod;
        public User(string sor)
        {
            string[] adatok = sor.Split(' ');
            this.nev = adatok[0];
            this.kod = adatok[1];
        }
    }
    class Termek
    {
        public static List<Termek> termeklista = new List<Termek>();
        public int id { get; set; }
        public string nev { get; set; }

        public Termek(int id, string termeknev)
        {
            this.id = id;
            this.nev = termeknev;
        }
        public Termek(string sor)
        {
            string[] adatok = sor.Split(';');
            this.id = int.Parse(adatok[0]);
            this.nev = adatok[1];
        }
        public static void Save()
        {
            StreamWriter sr = new StreamWriter("termekek.txt");
            foreach (var item in termeklista)
            {
                sr.WriteLine($"{item.id};{item.nev}");
            }
            sr.Close();
        }
    }
    class mentes
    {
        public static List<mentes> eladasok = new List<mentes>();
        public string nev { get; set; }
        public int mennyiseg { get; set; }
        public DateTime DateTime { get; set; }

        public mentes(string sor)
        {
            string[] adatok = sor.Split(';');
            this.nev = adatok[0];
            this.DateTime = DateTime.Parse(adatok[1]);
            this.mennyiseg = int.Parse(adatok[2]);
        }
        public mentes(string nev,DateTime dateTime,int mennyiseg) 
        {
            this.nev = nev;
            this.DateTime = dateTime;
            this.mennyiseg = mennyiseg;
        }
        public static void Save()
        {
            StreamWriter sr = new StreamWriter("mentes.txt");
            foreach (var item in eladasok)
            {
                sr.WriteLine($"{item.nev};{item.DateTime};{item.mennyiseg}");
            }
            sr.Close();
        }
    }
}